import React, { useState, useEffect } from "react";
import { Ticket } from "@/entities/Ticket";
import { Category } from "@/entities/Category";
import { User } from "@/entities/User";
import { UploadFile, InvokeLLM } from "@/integrations/Core";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Upload, 
  X, 
  Send, 
  ArrowLeft, 
  Lightbulb, 
  Tag,
  FileText,
  AlertCircle,
  Sparkles
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion, AnimatePresence } from "framer-motion";

export default function CreateTicket() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [categories, setCategories] = useState([]);
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    category_id: "",
    priority: "medium",
    tags: []
  });
  const [files, setFiles] = useState([]);
  const [suggestions, setSuggestions] = useState([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [currentTag, setCurrentTag] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    if (formData.title.length > 10 || formData.description.length > 20) {
      analyzeTitleForSuggestions();
    }
  }, [formData.title, formData.description]);

  const loadData = async () => {
    try {
      const [userData, categoryData] = await Promise.all([
        User.me(),
        Category.list()
      ]);
      setUser(userData);
      setCategories(categoryData);
    } catch (error) {
      console.error("Error loading data:", error);
    }
  };

  const analyzeTitleForSuggestions = async () => {
    if (!formData.title.trim() && !formData.description.trim()) return;
    
    setIsAnalyzing(true);
    try {
      const result = await InvokeLLM({
        prompt: `Based on this support ticket title "${formData.title}" and description "${formData.description}", provide helpful suggestions:
        1. Suggest the most appropriate category from: ${categories.map(c => c.name).join(', ')}
        2. Suggest priority level (low, medium, high, urgent)
        3. Suggest 2-3 relevant tags
        4. Find similar issues that might already exist
        
        Be concise and practical.`,
        response_json_schema: {
          type: "object",
          properties: {
            suggested_category: { type: "string" },
            suggested_priority: { type: "string" },
            suggested_tags: { type: "array", items: { type: "string" } },
            similar_issues: { type: "array", items: { type: "string" } }
          }
        }
      });

      setSuggestions(result);
    } catch (error) {
      console.error("Error analyzing ticket:", error);
    }
    setIsAnalyzing(false);
  };

  const handleFileUpload = async (event) => {
    const selectedFiles = Array.from(event.target.files);
    if (selectedFiles.length === 0) return;

    setIsUploading(true);
    try {
      const uploadPromises = selectedFiles.map(async (file) => {
        const { file_url } = await UploadFile({ file });
        return {
          name: file.name,
          url: file_url,
          size: file.size,
          type: file.type
        };
      });

      const uploadedFiles = await Promise.all(uploadPromises);
      setFiles(prev => [...prev, ...uploadedFiles]);
    } catch (error) {
      setError("Error uploading files. Please try again.");
    }
    setIsUploading(false);
  };

  const removeFile = (index) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
  };

  const addTag = () => {
    if (currentTag.trim() && !formData.tags.includes(currentTag.trim())) {
      setFormData(prev => ({
        ...prev,
        tags: [...prev.tags, currentTag.trim()]
      }));
      setCurrentTag("");
    }
  };

  const removeTag = (tagToRemove) => {
    setFormData(prev => ({
      ...prev,
      tags: prev.tags.filter(tag => tag !== tagToRemove)
    }));
  };

  const applySuggestion = (type, value) => {
    if (type === 'category') {
      const category = categories.find(c => c.name.toLowerCase() === value.toLowerCase());
      if (category) {
        setFormData(prev => ({ ...prev, category_id: category.id }));
      }
    } else if (type === 'priority') {
      setFormData(prev => ({ ...prev, priority: value }));
    } else if (type === 'tags') {
      const newTags = [...formData.tags];
      if (!newTags.includes(value)) {
        newTags.push(value);
        setFormData(prev => ({ ...prev, tags: newTags }));
      }
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.title.trim() || !formData.description.trim()) {
      setError("Title and description are required");
      return;
    }

    setIsSubmitting(true);
    setError("");

    try {
      const ticketData = {
        ...formData,
        reporter_email: user.email,
        attachment_urls: files.map(f => f.url),
        upvotes: 0,
        downvotes: 0,
        voted_by: []
      };

      await Ticket.create(ticketData);
      setSuccess("Ticket created successfully!");
      
      setTimeout(() => {
        navigate(createPageUrl("Tickets"));
      }, 1500);
    } catch (error) {
      setError("Error creating ticket. Please try again.");
    }
    setIsSubmitting(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Button
            variant="outline"
            size="icon"
            onClick={() => navigate(createPageUrl("Dashboard"))}
            className="hover:bg-slate-100"
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-slate-900 to-slate-600 bg-clip-text text-transparent">
              Create New Ticket
            </h1>
            <p className="text-slate-600">Describe your issue and we'll help you resolve it</p>
          </div>
        </div>

        {/* Success/Error Messages */}
        <AnimatePresence>
          {error && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="mb-6"
            >
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            </motion.div>
          )}
          {success && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="mb-6"
            >
              <Alert className="border-green-200 bg-green-50 text-green-800">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{success}</AlertDescription>
              </Alert>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Form */}
          <div className="lg:col-span-2">
            <Card className="bg-gradient-to-br from-white to-slate-50 border-slate-200/60 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-xl font-bold text-slate-900">
                  <FileText className="w-5 h-5" />
                  Ticket Details
                </CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* Title */}
                  <div className="space-y-2">
                    <Label htmlFor="title">Issue Title *</Label>
                    <Input
                      id="title"
                      value={formData.title}
                      onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                      placeholder="Brief description of your issue..."
                      className="text-lg"
                    />
                  </div>

                  {/* Description */}
                  <div className="space-y-2">
                    <Label htmlFor="description">Detailed Description *</Label>
                    <Textarea
                      id="description"
                      value={formData.description}
                      onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                      placeholder="Please provide as much detail as possible about your issue..."
                      className="min-h-32"
                    />
                  </div>

                  {/* Category and Priority */}
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Category</Label>
                      <Select 
                        value={formData.category_id} 
                        onValueChange={(value) => setFormData(prev => ({ ...prev, category_id: value }))}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                        <SelectContent>
                          {categories.map(category => (
                            <SelectItem key={category.id} value={category.id}>
                              {category.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label>Priority</Label>
                      <Select 
                        value={formData.priority} 
                        onValueChange={(value) => setFormData(prev => ({ ...prev, priority: value }))}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="low">Low</SelectItem>
                          <SelectItem value="medium">Medium</SelectItem>
                          <SelectItem value="high">High</SelectItem>
                          <SelectItem value="urgent">Urgent</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  {/* Tags */}
                  <div className="space-y-2">
                    <Label>Tags</Label>
                    <div className="flex gap-2 mb-2">
                      <Input
                        value={currentTag}
                        onChange={(e) => setCurrentTag(e.target.value)}
                        placeholder="Add tag..."
                        onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addTag())}
                        className="flex-1"
                      />
                      <Button type="button" onClick={addTag} variant="outline">
                        <Tag className="w-4 h-4" />
                      </Button>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {formData.tags.map(tag => (
                        <Badge key={tag} variant="secondary" className="gap-1">
                          {tag}
                          <X 
                            className="w-3 h-3 cursor-pointer hover:text-red-500" 
                            onClick={() => removeTag(tag)}
                          />
                        </Badge>
                      ))}
                    </div>
                  </div>

                  {/* File Upload */}
                  <div className="space-y-2">
                    <Label>Attachments</Label>
                    <div className="border-2 border-dashed border-slate-300 rounded-lg p-4 hover:border-emerald-400 transition-colors">
                      <input
                        type="file"
                        multiple
                        onChange={handleFileUpload}
                        className="hidden"
                        id="file-upload"
                        accept="image/*,.pdf,.doc,.docx,.txt"
                      />
                      <label htmlFor="file-upload" className="cursor-pointer">
                        <div className="text-center">
                          <Upload className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                          <p className="text-sm text-slate-600">
                            {isUploading ? "Uploading..." : "Click to upload files or drag and drop"}
                          </p>
                          <p className="text-xs text-slate-500 mt-1">
                            Images, PDFs, Documents up to 10MB
                          </p>
                        </div>
                      </label>
                    </div>

                    {/* File List */}
                    {files.length > 0 && (
                      <div className="space-y-2">
                        {files.map((file, index) => (
                          <div key={index} className="flex items-center justify-between p-2 bg-slate-50 rounded">
                            <div className="flex items-center gap-2">
                              <FileText className="w-4 h-4 text-slate-500" />
                              <span className="text-sm">{file.name}</span>
                              <span className="text-xs text-slate-400">
                                ({Math.round(file.size / 1024)}KB)
                              </span>
                            </div>
                            <Button
                              type="button"
                              variant="ghost"
                              size="sm"
                              onClick={() => removeFile(index)}
                            >
                              <X className="w-4 h-4" />
                            </Button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Submit Button */}
                  <div className="flex justify-end pt-4">
                    <Button
                      type="submit"
                      disabled={isSubmitting}
                      className="bg-gradient-to-r from-emerald-500 to-blue-500 hover:from-emerald-600 hover:to-blue-600 text-white shadow-lg hover:shadow-xl transition-all duration-300"
                    >
                      {isSubmitting ? (
                        <div className="flex items-center gap-2">
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                          Creating...
                        </div>
                      ) : (
                        <div className="flex items-center gap-2">
                          <Send className="w-4 h-4" />
                          Create Ticket
                        </div>
                      )}
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </div>

          {/* AI Suggestions Sidebar */}
          <div className="space-y-6">
            {/* AI Suggestions */}
            <Card className="bg-gradient-to-br from-white to-slate-50 border-slate-200/60 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg font-bold text-slate-900">
                  <Sparkles className="w-5 h-5 text-emerald-500" />
                  AI Suggestions
                  {isAnalyzing && (
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-emerald-500"></div>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {suggestions.suggested_category && (
                  <div className="space-y-2">
                    <Label className="text-sm font-medium text-slate-700">Suggested Category</Label>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => applySuggestion('category', suggestions.suggested_category)}
                      className="w-full justify-start hover:bg-emerald-50 hover:border-emerald-200"
                    >
                      <Lightbulb className="w-4 h-4 mr-2 text-emerald-500" />
                      {suggestions.suggested_category}
                    </Button>
                  </div>
                )}

                {suggestions.suggested_priority && (
                  <div className="space-y-2">
                    <Label className="text-sm font-medium text-slate-700">Suggested Priority</Label>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => applySuggestion('priority', suggestions.suggested_priority)}
                      className="w-full justify-start hover:bg-blue-50 hover:border-blue-200"
                    >
                      <AlertCircle className="w-4 h-4 mr-2 text-blue-500" />
                      {suggestions.suggested_priority.charAt(0).toUpperCase() + suggestions.suggested_priority.slice(1)}
                    </Button>
                  </div>
                )}

                {suggestions.suggested_tags && suggestions.suggested_tags.length > 0 && (
                  <div className="space-y-2">
                    <Label className="text-sm font-medium text-slate-700">Suggested Tags</Label>
                    <div className="flex flex-wrap gap-2">
                      {suggestions.suggested_tags.map(tag => (
                        <Button
                          key={tag}
                          variant="outline"
                          size="sm"
                          onClick={() => applySuggestion('tags', tag)}
                          className="text-xs hover:bg-purple-50 hover:border-purple-200"
                        >
                          <Tag className="w-3 h-3 mr-1" />
                          {tag}
                        </Button>
                      ))}
                    </div>
                  </div>
                )}

                {suggestions.similar_issues && suggestions.similar_issues.length > 0 && (
                  <div className="space-y-2">
                    <Label className="text-sm font-medium text-slate-700">Similar Issues Found</Label>
                    <div className="space-y-2">
                      {suggestions.similar_issues.slice(0, 3).map((issue, index) => (
                        <div key={index} className="p-2 bg-yellow-50 border border-yellow-200 rounded text-xs">
                          {issue}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {!suggestions.suggested_category && !isAnalyzing && (formData.title || formData.description) && (
                  <div className="text-center py-4">
                    <Sparkles className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                    <p className="text-sm text-slate-500">
                      Keep typing to get AI suggestions...
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Quick Tips */}
            <Card className="bg-gradient-to-br from-emerald-50 to-blue-50 border-emerald-200/60 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg font-bold text-slate-900">
                  <Lightbulb className="w-5 h-5 text-emerald-600" />
                  Quick Tips
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm text-slate-700">
                <div className="flex items-start gap-2">
                  <div className="w-2 h-2 bg-emerald-500 rounded-full mt-1.5"></div>
                  <p>Be specific in your title - it helps our AI categorize better</p>
                </div>
                <div className="flex items-start gap-2">
                  <div className="w-2 h-2 bg-blue-500 rounded-full mt-1.5"></div>
                  <p>Include error messages or screenshots when possible</p>
                </div>
                <div className="flex items-start gap-2">
                  <div className="w-2 h-2 bg-purple-500 rounded-full mt-1.5"></div>
                  <p>Use tags to help others find similar issues</p>
                </div>
                <div className="flex items-start gap-2">
                  <div className="w-2 h-2 bg-orange-500 rounded-full mt-1.5"></div>
                  <p>Set priority based on business impact</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}