import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ArrowUp, ArrowDown } from "lucide-react";
import { Ticket } from "@/entities/Ticket";
import { motion } from 'framer-motion';

const statusConfig = {
  open: { color: 'bg-orange-100 text-orange-800 border-orange-200', label: 'Open' },
  in_progress: { color: 'bg-blue-100 text-blue-800 border-blue-200', label: 'In Progress' },
  resolved: { color: 'bg-green-100 text-green-800 border-green-200', label: 'Resolved' },
  closed: { color: 'bg-slate-100 text-slate-800 border-slate-200', label: 'Closed' }
};

export default function TicketHeader({ ticket, category, user, onUpdate }) {
  const handleVote = async (voteType) => {
    if (!user) return;

    let { upvotes, downvotes, voted_by } = ticket;
    voted_by = voted_by || [];
    
    const existingVote = voted_by.find(v => v.user_email === user.email);

    if (existingVote) {
      if (existingVote.vote_type === voteType) return; // Already voted this way

      // Switch vote
      voted_by = voted_by.map(v => v.user_email === user.email ? { ...v, vote_type: voteType } : v);
      if (voteType === 'up') {
        upvotes = (upvotes || 0) + 1;
        downvotes = Math.max(0, (downvotes || 0) - 1);
      } else {
        downvotes = (downvotes || 0) + 1;
        upvotes = Math.max(0, (upvotes || 0) - 1);
      }
    } else {
      // New vote
      voted_by.push({ user_email: user.email, vote_type: voteType });
      if (voteType === 'up') {
        upvotes = (upvotes || 0) + 1;
      } else {
        downvotes = (downvotes || 0) + 1;
      }
    }

    try {
      const updatedTicket = await Ticket.update(ticket.id, { upvotes, downvotes, voted_by });
      onUpdate(updatedTicket);
    } catch (error) {
      console.error("Error updating vote:", error);
    }
  };

  const userVote = ticket.voted_by?.find(v => v.user_email === user?.email)?.vote_type;

  return (
    <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 shadow-lg">
      <CardHeader>
        <div className="flex flex-col md:flex-row justify-between items-start gap-4">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-3 mb-2">
              {category && (
                <Badge 
                  style={{ 
                    backgroundColor: `${category.color}20`,
                    color: category.color,
                    borderColor: `${category.color}40`
                  }}
                  className="font-semibold"
                >
                  {category.name}
                </Badge>
              )}
              <Badge variant="outline" className={statusConfig[ticket.status].color}>
                {statusConfig[ticket.status].label}
              </Badge>
            </div>
            <CardTitle className="text-2xl md:text-3xl font-bold text-slate-900">
              {ticket.title}
            </CardTitle>
          </div>
          <div className="flex items-center gap-2">
            <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
              <Button 
                variant="outline" 
                size="icon" 
                onClick={() => handleVote('up')}
                className={userVote === 'up' ? 'bg-emerald-100 border-emerald-300' : ''}
              >
                <ArrowUp className="w-5 h-5 text-emerald-600" />
              </Button>
            </motion.div>
            <span className="text-xl font-bold w-10 text-center">{ticket.upvotes || 0}</span>
            <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
              <Button 
                variant="outline" 
                size="icon" 
                onClick={() => handleVote('down')}
                className={userVote === 'down' ? 'bg-red-100 border-red-300' : ''}
              >
                <ArrowDown className="w-5 h-5 text-red-600" />
              </Button>
            </motion.div>
          </div>
        </div>
      </CardHeader>
    </Card>
  );
}
